/*
 * legacy support. core.js moved to wwwRoothttps://s3.amazonaws.com/cdn.contensive.com/assets/20190729/admin.js
*/
(function () {
    var script = document.createElement("script");
    script.src = "https://s3.amazonaws.com/cdn.contensive.com/assets/20190729/admin.js";
    document.head.appendChild(script);
}());