<textarea id="##ELEMENTNAME##" name="##ELEMENTNAME##" width="##WIDTH##" height="##HEIGHT##">##CONTENT##</textarea>
<script language=JavaScript>
var ##EDITORNAME## = new InnovaEditor("##EDITORNAME##");
##EDITORNAME##.width="100%"; 
##EDITORNAME##.height="500px"; 
##EDITORNAME##.btnPrint=true;
##EDITORNAME##.btnPasteText=true;
##EDITORNAME##.btnLTR=true;
##EDITORNAME##.btnRTL=true;
##EDITORNAME##.btnStrikethrough=true;
##EDITORNAME##.btnSuperscript=true;
##EDITORNAME##.btnSubscript=true;
##EDITORNAME##.btnClearAll=true;
##EDITORNAME##.btnStyles=true;
##EDITORNAME##.css="/ccDemo/styles.css";
##EDITORNAME##.arrCustomTag=##CUSTOMTAG##;
##EDITORNAME##.cmdCustomObject="OpenResourceLibrary('##EDITORNAME##')";
##EDITORNAME##.REPLACE("##ELEMENTNAME##");
</script>
