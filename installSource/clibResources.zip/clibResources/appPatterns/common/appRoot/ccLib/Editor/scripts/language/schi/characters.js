function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML\u6e90\u7801 ";
    document.getElementById("btnClose").value = "\u5173\u95ed ";
    }
function writeTitle()
    {
    document.write("<title>\u7279\u6b8a\u5b57\u7b26 </title>")
    }
