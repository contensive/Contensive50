function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Navn";
    document.getElementById("btnCancel").value = "Annuller";
    document.getElementById("btnInsert").value = unescape("Inds%E6t");
    document.getElementById("btnApply").value = "Opdater";
    document.getElementById("btnOk").value = " Ok ";
    }
function writeTitle()
    {
    document.write("<title>"+"Bogm\u00E6rke"+"</title>")
    }