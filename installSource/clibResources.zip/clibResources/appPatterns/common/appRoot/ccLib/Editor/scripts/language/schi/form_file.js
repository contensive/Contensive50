function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "\u540d\u79f0 ";
    
    document.getElementById("btnCancel").value = "\u53d6\u6d88 ";
    document.getElementById("btnInsert").value = "\u63d2\u5165 ";
    document.getElementById("btnApply").value = "\u5e94\u7528 ";
    document.getElementById("btnOk").value = " \u786e\u8ba4  ";
    }
function writeTitle()
    {
    document.write("<title>\u6863\u6848\u5b57\u6bb5 </title>")
    }
