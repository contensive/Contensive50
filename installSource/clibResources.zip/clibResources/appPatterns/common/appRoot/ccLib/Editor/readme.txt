InnovaStudio WYSIWYG Editor 2.9.6
Copyright � 2003-2005, INNOVA STUDIO (www.InnovaStudio.com). All rights reserved.
____________________________________________________________________


*** Installation ***
1. Unzip the package & copy all files into your web folder.
(According to several examples, it is recomended that you copy all files into http://yourserver/Editor/  or http://localhost/Editor/)
2. To browse the examples, open default.htm 
(http://yourserver/Editor/default.htm  or http://localhost/Editor/default.htm)


*** Support ***
We provide 1 year FREE limited support (support@innovastudio.com) for every purchase of license. 
We provide support to make sure that you have the source code/package installed & run correctly on your machine.


*** IMPORTANT ***
We do not provide free customization service for the products we sell. 
Any customization work, custom integration or troubleshooting your 
custom application are beyond our support objective.


Thank you for using our product.

____________________________________________________________________
http://www.InnovaStudio.com
