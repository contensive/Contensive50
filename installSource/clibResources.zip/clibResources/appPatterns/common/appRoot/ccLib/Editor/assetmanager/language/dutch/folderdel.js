function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Weet u zeker dat u deze map wilt verwijderen ?";

    document.getElementById("btnClose").value = "sluiten";
    document.getElementById("btnDelete").value = "verwijderen";
    }
function writeTitle()
    {
    document.write("<title>Map Verwijderen</title>")
    }
