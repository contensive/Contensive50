function loadTxt()
    {
    document.getElementById("btnCancel").value = "Cancelar";
    document.getElementById("btnOk").value = " Aceptar ";
    }
function writeTitle()
    {
    document.write("<title>Porcentaje&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</title>")
    }