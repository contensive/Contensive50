function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Plak hier uw inhoud vanuit Word";
    document.getElementById("btnCancel").value = "annuleren";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Plakken vanuit Word</title>")
	}
