Public MustInherit Class CPSiteBaseClass
    Public MustOverride ReadOnly Property name() As String
    Public MustOverride Sub setProperty(ByVal FieldName As String, ByVal FieldValue As String)
    Public MustOverride Function getProperty(ByVal FieldName As String, Optional ByVal DefaultValue As String = "") As String
    Public MustOverride ReadOnly Property multiDomainMode() As Boolean
    Public MustOverride ReadOnly Property physicalFilePath() As String
    Public MustOverride ReadOnly Property physicalInstallPath() As String
    Public MustOverride ReadOnly Property physicalWWWPath() As String
    Public MustOverride ReadOnly Property trapErrors() As Boolean
    Public MustOverride ReadOnly Property appPath() As String
    Public MustOverride ReadOnly Property appRootPath() As String
    Public MustOverride ReadOnly Property domainPrimary() As String
    Public MustOverride ReadOnly Property domain() As String
    Public MustOverride ReadOnly Property domainList() As String
    Public MustOverride ReadOnly Property filePath() As String
    Public MustOverride ReadOnly Property pageDefault() As String
    Public MustOverride ReadOnly Property virtualPath() As String
    Public MustOverride Function encodeAppRootPath(ByVal Link As String) As String
    Public MustOverride Function isTesting() As Boolean
    Public MustOverride Sub logActivity(ByVal Message As String, ByVal UserID As Integer, ByVal OrganizationID As Integer)
    Public MustOverride Sub logAlarm(ByVal Message As String)
    Public MustOverride Sub logWarning(ByVal name As String, ByVal description As String, ByVal generalKey As String, ByVal specificKey As String)
    Public MustOverride Sub errorReport(ByVal Message As String)
    Public MustOverride Sub errorReport(ByVal Ex As System.Exception, Optional ByVal Message As String = "")
    Public MustOverride Sub errorReport(ByVal Err As Microsoft.VisualBasic.ErrObject, Optional ByVal Message As String = "")
    Public MustOverride Sub requestTask(ByVal Command As String, ByVal SQL As String, ByVal ExportName As String, ByVal Filename As String)
    Public MustOverride Sub testPoint(ByVal Message As String)
    Public MustOverride Function landingPageId(Optional ByVal DomainName As String = "") As Integer
End Class
