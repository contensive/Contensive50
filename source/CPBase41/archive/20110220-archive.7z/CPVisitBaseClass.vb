

Public MustInherit Class CPVisitBaseClass
    Public MustOverride ReadOnly Property cookieSupport() As Boolean
    Public MustOverride Function getProperty(ByVal PropertyName As String, Optional ByVal DefaultValue As String = "", Optional ByVal TargetVisitId As Integer = 0) As String
    Public MustOverride ReadOnly Property id() As Integer
    Public MustOverride ReadOnly Property lastTime() As Date
    Public MustOverride ReadOnly Property loginAttempts() As Integer
    Public MustOverride ReadOnly Property name() As String
    Public MustOverride ReadOnly Property pages() As Integer
    Public MustOverride ReadOnly Property referer() As String
    Public MustOverride Sub setProperty(ByVal PropertyName As String, ByVal Value As String, Optional ByVal TargetVisitId As Integer = 0)
    Public MustOverride ReadOnly Property startDateValue() As Integer
    Public MustOverride ReadOnly Property startTime() As Date
End Class
