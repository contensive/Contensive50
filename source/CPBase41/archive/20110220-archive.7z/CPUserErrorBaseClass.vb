Public MustInherit Class CPUserErrorBaseClass
    Public MustOverride Sub add(ByVal Message As String)
    Public MustOverride Function getList() As String
    Public MustOverride Function ok() As Boolean
End Class
