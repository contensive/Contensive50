''' <summary>
''' CP.Db - This object references the database directly
''' </summary>
''' <remarks></remarks>
Public MustInherit Class CPDbBaseClass
    Public MustOverride Sub delete(ByVal DataSourcename As String, ByVal TableName As String, ByVal RecordId As Integer)
    Public MustOverride Function dbGetConnectionString(ByVal DataSourcename As String) As String
    Public MustOverride Function dbGetDataSourceType(ByVal DataSourcename As String) As Integer
    Public MustOverride Function dbGetTableID(ByVal TableName As String) As Integer
    Public MustOverride Function dbIsTable(ByVal DataSourcename As String, ByVal TableName As String) As Boolean
    Public MustOverride Function dbIsTableField(ByVal DataSourcename As String, ByVal TableName As String, ByVal FieldName As String) As Boolean
    Public MustOverride Function encodeSQLBoolean(ByVal SourceBoolean As Boolean) As String
    Public MustOverride Function encodeSQLDate(ByVal SourceDate As Date) As String
    Public MustOverride Function encodeSQLNumber(ByVal SourceNumber As Double) As String
    Public MustOverride Function encodeSQLText(ByVal SourceText As String) As String
    Public MustOverride Function executeSQL(ByVal SQL As String, Optional ByVal DataSourcename As String = "Default", Optional ByVal Retries As String = "0", Optional ByVal PageSize As String = "10", Optional ByVal PageNumber As String = "1") As Object
    Public MustOverride Property sqlTimeout() As Integer
End Class
