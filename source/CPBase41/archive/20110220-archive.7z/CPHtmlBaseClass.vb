
Public MustInherit Class CPHtmlBaseClass

    ' these are contentTypeEnum and userTypeEnum, restore when InputHtml is restored
    'Enum EditorContentScope
    '    page = 1
    '    email = 2
    '    pageTemplate = 3
    '    emailTemplate = 4
    'End Enum
    ''
    'Enum EditorUserScope
    '    Developer = 1
    '    Administrator = 2
    '    ContentManager = 3
    '    PublicUser = 4
    '    CurrentUser = 5
    'End Enum
    'Public Sub New(ByVal MainObj As Object, ByVal CsvObj As Object, ByRef CPParent As CPBaseClass)
    Public MustOverride Function div(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function p(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function li(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function ul(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function ol(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function checkBox(ByVal HtmlName As String, Optional ByVal HtmlValue As Boolean = False, Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function checkList(ByVal HtmlName As String, ByVal PrimaryContentName As String, ByVal PrimaryRecordId As Integer, ByVal SecondaryContentName As String, ByVal RulesContentName As String, ByVal RulesPrimaryFieldname As String, ByVal RulesSecondaryFieldName As String, Optional ByVal SecondaryContentSelectSQLCriteria As String = "", Optional ByVal CaptionFieldName As String = "", Optional ByVal IsReadOnly As Boolean = False, Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function form(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "", Optional ByVal ActionQueryString As String = "", Optional ByVal Method As String = "post") As String
    Public MustOverride Function h1(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function h2(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function h3(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function h4(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function h5(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function h6(ByVal InnerHtml As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function radioBox(ByVal HtmlName As String, ByVal HtmlValue As String, ByVal CurrentValue As String, Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function selectContent(ByVal HtmlName As String, ByVal HtmlValue As String, ByVal ContentName As String, Optional ByVal SQLCriteria As String = "", Optional ByVal NoneCaption As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function selectList(ByVal HtmlName As String, ByVal HtmlValue As String, ByVal OptionList As String, Optional ByVal NoneCaption As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Sub processCheckList(ByVal HtmlName As String, ByVal PrimaryContentName As String, ByVal PrimaryRecordID As String, ByVal SecondaryContentName As String, ByVal RulesContentName As String, ByVal RulesPrimaryFieldname As String, ByVal RulesSecondaryFieldName As String)
    Public MustOverride Sub processInputFile(ByVal HtmlName As String, Optional ByVal VirtualFilePath As String = "")
    Public MustOverride Function hidden(ByVal HtmlName As String, ByVal HtmlValue As String, Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function inputDate(ByVal HtmlName As String, Optional ByVal HtmlValue As String = "", Optional ByVal Width As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function inputFile(ByVal HtmlName As String, Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function inputText(ByVal HtmlName As String, Optional ByVal HtmlValue As String = "", Optional ByVal Height As String = "", Optional ByVal Width As String = "", Optional ByVal IsPassword As Boolean = False, Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function inputTextExpandable(ByVal HtmlName As String, Optional ByVal HtmlValue As String = "", Optional ByVal Rows As Integer = 0, Optional ByVal StyleWidth As String = "", Optional ByVal IsPassword As Boolean = False, Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    ' convert to new InputHtml when all the arguments are understood (contentType, stylelist, styleoptions, etc)
    'Public MustOverride Function InputWysiwyg(ByVal HtmlName As String, Optional ByVal HtmlValue As String = "", Optional ByVal UserScope As BaseClasses.CPHtmlBaseClass.EditorUserScope = BaseClasses.CPHtmlBaseClass.EditorUserScope.CurrentUser, Optional ByVal ContentScope As BaseClasses.CPHtmlBaseClass.EditorContentScope = BaseClasses.CPHtmlBaseClass.EditorContentScope.Page, Optional ByVal Height As String = "", Optional ByVal Width As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String 'Implements BaseClasses.CPHtmlBaseClass.InputWysiwyg
    Public MustOverride Function inputField(ByVal contentName As String, ByVal fieldName As String, Optional ByVal HtmlName As String = "", Optional ByVal HtmlValue As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "", Optional ByVal HtmlStyle As String = "", Optional ByVal ManyToManySourceRecordID As Integer = 0) As String
    Public MustOverride Function selectUser(ByVal HtmlName As String, ByVal HtmlValue As Integer, ByVal GroupId As Integer, Optional ByVal NoneCaption As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
    Public MustOverride Function indent(ByVal SourceHtml As String, Optional ByVal TabCnt As Integer = 1) As String
    Public MustOverride Sub addEvent(ByVal HtmlId As String, ByVal DOMEvent As String, ByVal JavaScript As String)
    Public MustOverride Function button(ByVal HtmlName As String, Optional ByVal HtmlValue As String = "", Optional ByVal HtmlClass As String = "", Optional ByVal HtmlId As String = "") As String
End Class
