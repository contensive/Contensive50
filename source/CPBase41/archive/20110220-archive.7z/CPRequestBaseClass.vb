

Public MustInherit Class CPRequestBaseClass
    Public MustOverride ReadOnly Property browser() As String
    Public MustOverride ReadOnly Property browserIsIE() As Boolean
    Public MustOverride ReadOnly Property browserIsMac() As Boolean
    Public MustOverride ReadOnly Property browserIsMobile() As Boolean
    Public MustOverride ReadOnly Property browserIsWindows() As Boolean
    Public MustOverride ReadOnly Property browserVersion() As String
    Public MustOverride Function cookie(ByVal CookieName As String) As String
    Public MustOverride ReadOnly Property cookieString() As String
    Public MustOverride ReadOnly Property form() As String
    Public MustOverride ReadOnly Property formAction() As String
    Public MustOverride Function getBoolean(ByVal requestName As String) As Boolean
    Public MustOverride Function getDate(ByVal requestName As String) As Date
    Public MustOverride Function getInteger(ByVal requestName As String) As Integer
    Public MustOverride Function getNumber(ByVal requestName As String) As Double
    Public MustOverride Function getText(ByVal requestName As String) As String
    Public MustOverride ReadOnly Property host() As String
    Public MustOverride ReadOnly Property httpAccept() As String
    Public MustOverride ReadOnly Property httpAcceptCharset() As String
    Public MustOverride ReadOnly Property httpProfile() As String
    Public MustOverride ReadOnly Property httpXWapProfile() As String
    Public MustOverride ReadOnly Property language() As String
    Public MustOverride ReadOnly Property link() As String
    Public MustOverride ReadOnly Property linkForwardSource() As String
    Public MustOverride ReadOnly Property linkSource() As String
    Public MustOverride ReadOnly Property page() As String
    Public MustOverride ReadOnly Property path() As String
    Public MustOverride ReadOnly Property pathPage() As String
    Public MustOverride ReadOnly Property protocol() As String
    Public MustOverride ReadOnly Property queryString() As String
    Public MustOverride ReadOnly Property referer() As String
    Public MustOverride ReadOnly Property remoteIP() As String
    Public MustOverride ReadOnly Property secure() As Boolean
    Public MustOverride Function ok(ByVal requestName As String) As Boolean
End Class
