
Public MustInherit Class CPGroupBaseClass
    Public MustOverride Sub add(ByVal GroupName As String, Optional ByVal GroupCaption As String = "")
    Public MustOverride Sub addUser(ByVal GroupName As String, Optional ByVal UserId As Integer = 0, Optional ByVal DateExpires As Date = #12:00:00 AM#)
    Public MustOverride Sub delete(ByVal GroupName As String)
    Public MustOverride Function getId(ByVal GroupName As String) As Integer
    Public MustOverride Function getName(ByVal GroupId As String) As String
    Public MustOverride Sub removeUser(ByVal GroupName As String, Optional ByVal UserId As Integer = 0)
End Class
