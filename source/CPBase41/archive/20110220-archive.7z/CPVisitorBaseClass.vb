

Public MustInherit Class CPVisitorBaseClass
    Public MustOverride ReadOnly Property forceBrowserMobile() As Boolean
    Public MustOverride Function getProperty(ByVal PropertyName As String, Optional ByVal DefaultValue As String = "", Optional ByVal TargetVisitorId As Integer = 0) As String
    Public MustOverride ReadOnly Property id() As Integer
    Public MustOverride ReadOnly Property isNew() As Boolean
    Public MustOverride Sub setProperty(ByVal PropertyName As String, ByVal Value As String, Optional ByVal TargetVisitorid As Integer = 0)
    Public MustOverride ReadOnly Property userId() As Integer
End Class
