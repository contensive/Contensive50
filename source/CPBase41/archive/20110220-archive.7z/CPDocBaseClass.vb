
Public MustInherit Class CPDocBaseClass
    Public MustOverride Property content() As String
    Public MustOverride ReadOnly Property navigationStructure() As String
    Public MustOverride Property noFollow() As Boolean
    Public MustOverride ReadOnly Property pageId() As Integer
    Public MustOverride ReadOnly Property pageName() As String
    Public MustOverride ReadOnly Property refreshQueryString() As String
    Public MustOverride ReadOnly Property sectionId() As Integer
    Public MustOverride ReadOnly Property startTime() As Date
    Public MustOverride ReadOnly Property templateId() As Integer
    Public MustOverride ReadOnly Property type() As String
    Public MustOverride Sub addHeadStyle(ByVal StyleSheet As String)
    Public MustOverride Sub addHeadStyleLink(ByVal StyleSheetLink As String)
    Public MustOverride Sub addHeadJavascript(ByVal NewCode As String)
    Public MustOverride Sub addHeadTag(ByVal HeadTag As String)
    Public MustOverride Sub addMetaDescription(ByVal MetaDescription As String)
    Public MustOverride Sub addMetaKeywordList(ByVal MetaKeywordList As String)
    Public MustOverride Sub addOnLoadJavascript(ByVal NewCode As String)
    Public MustOverride Sub addTitle(ByVal PageTitle As String)
    Public MustOverride Sub addRefreshQueryString(ByVal Name As String, ByVal Value As String)
    Public MustOverride Sub addBodyEnd(ByVal NewCode As String)
    Public MustOverride Property body() As String
    Public MustOverride Property globalVar(ByVal Index As String) As String
    Public MustOverride ReadOnly Property isGlobalVar(ByVal Index As String) As Boolean
    Public MustOverride ReadOnly Property isVar(ByVal Index As String) As Boolean
    Public MustOverride Property var(ByVal Index As String) As String
    Public MustOverride ReadOnly Property siteStylesheet() As String
End Class
