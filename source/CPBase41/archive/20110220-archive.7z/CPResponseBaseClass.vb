'
'
'
Public MustInherit Class CPResponseBaseClass
    Public MustOverride Property contentType() As String
    Public MustOverride ReadOnly Property cookies() As String
    Public MustOverride ReadOnly Property header() As String
    Public MustOverride Sub clear()
    Public MustOverride Sub close()
    Public MustOverride Sub addHeader(ByVal headerName As String, ByVal headerValue As String)
    Public MustOverride Sub flush()
    Public MustOverride Sub redirect(ByVal link As String)
    Public MustOverride Sub setBuffer(ByVal bufferOn As Boolean)
    Public MustOverride Sub setStatus(ByVal status As String)
    Public MustOverride Sub setTimeout(ByVal timeoutSeconds As String)
    Public MustOverride Sub setType(ByVal contentType As String)
    Public MustOverride Sub setCookie(ByVal cookieName As String, ByVal cookieValue As String, Optional ByVal DateExpires As Date = #12:00:00 AM#, Optional ByVal Domain As String = "", Optional ByVal Path As String = "", Optional ByVal Secure As Boolean = False)
    Public MustOverride Sub write(ByVal content As String)
End Class
