''' <summary>
''' CP - The object passed to an addon in the add-ons execute method. See the AddonBaseClass for details of the addon execute method.
''' </summary>
''' <remarks></remarks>
Public MustInherit Class CPBaseClass
    'Public MustOverride Sub addVar(ByVal OptionName As String, ByVal OptionValue As String)
    'Public MustOverride Sub Init(ByVal MainObj As Object, ByVal CsvObj As Object, ByRef CPParent As CPBaseClass) ' 'Implements BaseClasses.CPBaseClass.Init
    'Public MustOverride Function executeAddonFromCsv(ByVal AddonID As Integer, ByVal AddonDisplayName As String, ByVal AddonPath As String, ByVal TypeFullName As String) As String ' 'Implements BaseClasses.CPBaseClass.ExecuteAddonFromCsv
    ''' <summary>
    ''' Factory for new CS object. See CPCSBaseClass for CS object details 
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function csNew() As BaseClasses.CPCSBaseClass 'Implements BaseClasses.CPBaseClass.CSNew
    ''' <summary>
    ''' Contensive version
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property version() As String 'Implements BaseClasses.CPBaseClass.Version
    ''' <summary>
    ''' The Group Object accesses group features. Group Features generally associate people and roles. See CPGroupBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property group() As BaseClasses.CPGroupBaseClass 'Implements BaseClasses.CPBaseClass.Group
    ''' <summary>
    ''' The Request object handles data associated with the request from the visitor. See CPRequestBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property request() As BaseClasses.CPRequestBaseClass 'Implements BaseClasses.CPBaseClass.Request
    ''' <summary>
    ''' The Response object handles the stream of data back to the visitor. See CPResponseBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property response() As BaseClasses.CPResponseBaseClass 'Implements BaseClasses.CPBaseClass.Response
    ''' <summary>
    ''' The UserError Class handles error handling for those conditions you want the user to know about or correct. For example an login error. See the CPUserErrorBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property userError() As BaseClasses.CPUserErrorBaseClass 'Implements BaseClasses.CPBaseClass.UserError
    ''' <summary>
    ''' The Visit Class handles details related to the visit. For instance it holds the number of pages hit so far and has methods for adding and modifying user defined visit properties. See CPVisitBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property visit() As BaseClasses.CPVisitBaseClass 'Implements BaseClasses.CPBaseClass.Visit
    ''' <summary>
    ''' The Visitor Class handles details related to the visitor. For instance it holds the browser type used by the visitor. See CPVisitorBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property visitor() As BaseClasses.CPVisitorBaseClass 'Implements BaseClasses.CPBaseClass.Visitor
    ''' <summary>
    ''' The User Class handles details related to the user and its related people record. See CPUserBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property user() As BaseClasses.CPUserBaseClass 'Implements BaseClasses.CPBaseClass.User
    ''' <summary>
    ''' The HTML class handles functions used to read and produce HTML elements. See CPHtmlBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property html() As BaseClasses.CPHtmlBaseClass 'Implements BaseClasses.CPBaseClass.Html
    ''' <summary>
    ''' The Cache objects handles caching. Use this class to save blocks of data you will use again. See CPCacheBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property cache() As BaseClasses.CPCacheBaseClass 'Implements BaseClasses.CPBaseClass.Cache
    ''' <summary>
    ''' The Db object handles direct access to the Database. The ContentSet functions in the CPCSBaseClass are prefered for general use. See the CPDBBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property db() As BaseClasses.CPDbBaseClass 'Implements BaseClasses.CPBaseClass.Db
    ''' <summary>
    ''' The Email object handles email functions. See CPEmailBaseClass for more information.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property email() As BaseClasses.CPEmailBaseClass 'Implements BaseClasses.CPBaseClass.Email
    ''' <summary>
    ''' The Content class handles functions related to content meta such as determining the table used for a content definition, getting a recordid based on the name, or accessing the methods that control workflow publishing. See CPContentBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property content() As BaseClasses.CPContentBaseClass 'Implements BaseClasses.CPBaseClass.Content
    ''' <summary>
    ''' The addon class handles access to an add-on's features. Use the Utils object to run an addon. An instance of the Addon class is passed to the executing addon in the MyAddon object so it can access any features needed. See the CPAddonBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property addon() As BaseClasses.CPAddonBaseClass 'Implements BaseClasses.CPBaseClass.Addon
    ''' <summary>
    ''' The Utils class handles basic utilities and other features not classified. See CPUtilsBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property utils() As BaseClasses.CPUtilsBaseClass 'Implements BaseClasses.CPBaseClass.Utils
    ''' <summary>
    ''' The Doc object handles features related to the document (page) being contructed in the current call. See CPDocBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property doc() As BaseClasses.CPDocBaseClass 'Implements BaseClasses.CPBaseClass.Doc
    ''' <summary>
    ''' The Site Class handles features related to the current site. See CPSiteBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property site() As BaseClasses.CPSiteBaseClass 'Implements BaseClasses.CPBaseClass.Site
    ''' <summary>
    ''' The MyAddon object is an instance of the Addon class created before an add-ons execute method is called. See CPAddonBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property myAddon() As BaseClasses.CPAddonBaseClass 'Implements BaseClasses.CPBaseClass.MyAddon
    ''' <summary>
    ''' The file object handles file system methods. See CPFileBaseClass for more details.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride ReadOnly Property file() As BaseClasses.CPFileBaseClass 'Implements BaseClasses.CPBaseClass.File
End Class
