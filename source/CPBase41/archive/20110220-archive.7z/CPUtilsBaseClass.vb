
Public MustInherit Class CPUtilsBaseClass
    Enum addonContext
        ContextPage = 1
        ContextAdmin = 2
        ContextTemplate = 3
        ContextEmail = 4
        ContextRemoteMethod = 5
        ContextOnNewVisit = 6
        ContextOnPageEnd = 7
        ContextOnPageStart = 8
        ContextEditor = 9
        ContextHelpUser = 10
        ContextHelpAdmin = 11
        ContextHelpDeveloper = 12
        ContextOnContentChange = 13
        ContextFilter = 14
        ContextSimple = 15
        ContextOnBodyStart = 16
        ContextOnBodyEnd = 17
    End Enum

    Public MustOverride Function convertHTML2Text(ByVal Source As String) As String
    Public MustOverride Function convertText2HTML(ByVal Source As String) As String
    Public MustOverride Function createGuid() As String
    Public MustOverride Function decodeUrl(ByVal Url As String) As String
    Public MustOverride Function encodeContentForWeb(ByVal Source As String, Optional ByVal ContextContentName As String = "", Optional ByVal ContextRecordID As Integer = 0, Optional ByVal WrapperID As Integer = 0) As String
    Public MustOverride Function decodeHTML(ByVal Source As String) As String
    Public MustOverride Function encodeHTML(ByVal Source As String) As String
    Public MustOverride Function encodeUrl(ByVal Source As String) As String
    Public MustOverride Function getPleaseWaitEnd() As String
    Public MustOverride Function getPleaseWaitStart() As String
    Public MustOverride Sub iisReset()
    Public MustOverride Function encodeInteger(ByVal Expression As Object) As Integer
    Public MustOverride Function encodeNumber(ByVal Expression As Object) As Double
    Public MustOverride Function encodeText(ByVal Expression As Object) As String
    Public MustOverride Function encodeBoolean(ByVal Expression As Object) As Boolean
    Public MustOverride Function encodeDate(ByVal Expression As Object) As Date
    Public MustOverride Function executeAddon(ByVal IdGuidOrName As String) As String
    Public MustOverride Function executeAddon(ByVal IdGuidOrName As String, ByVal WrapperId As Integer) As String
    Public MustOverride Function executeAddon(ByVal IdGuidOrName As String, ByVal context As addonContext) As String
    Public MustOverride Function executeAddonAsProcess(ByVal IdGuidOrName As String) As String
    Public MustOverride Sub appendLog(ByVal Filename As String, ByVal Text As String)
    Public MustOverride Sub appendLogFile(ByVal Text As String)
    Public MustOverride Function convertLinkToShortLink(ByVal URL As String, ByVal ServerHost As String, ByVal ServerVirtualPath As String) As String
    Public MustOverride Function convertShortLinkToLink(ByVal URL As String, ByVal PathPagePrefix As String) As String
    Public MustOverride Function decodeGMTDate(ByVal GMTDate As String) As Date
    Public MustOverride Function decodeResponseVariable(ByVal Source As String) As String
    Public MustOverride Function encodeJavascript(ByVal Source As String) As String
    Public MustOverride Function encodeQueryString(ByVal Source As String) As String
    Public MustOverride Function encodeRequestVariable(ByVal Source As String) As String
    Public MustOverride Function getArgument(ByVal Name As String, ByVal ArgumentString As String, Optional ByVal DefaultValue As String = "", Optional ByVal Delimiter As String = "") As String
    Public MustOverride Function getFilename(ByVal PathFilename As String) As String
    Public MustOverride Function getFirstNonZeroDate(ByVal Date0 As Date, ByVal Date1 As Date) As Date
    Public MustOverride Function getFirstNonZeroInteger(ByVal Integer0 As Integer, ByVal Integer1 As Integer) As Integer
    Public MustOverride Function getIntegerString(ByVal Value As Integer, ByVal DigitCount As Integer) As String
    Public MustOverride Function getLine(ByVal Body As String) As String
    Public MustOverride Function getListIndex(ByVal Item As String, ByVal ListOfItems As String) As Integer
    Public MustOverride Function getProcessID() As Integer
    Public MustOverride Function getRandomInteger() As Integer
    Public MustOverride Function isInDelimitedString(ByVal DelimitedString As String, ByVal TestString As String, ByVal Delimiter As String) As Boolean
    Public MustOverride Function modifyLinkQueryString(ByVal Link As String, ByVal QueryName As String, ByVal QueryValue As String, Optional ByVal AddIfMissing As Boolean = True) As String
    Public MustOverride Function modifyQueryString(ByVal WorkingQuery As String, ByVal QueryName As String, ByVal QueryValue As String, Optional ByVal AddIfMissing As Boolean = True) As String
    Public MustOverride Sub parseURL(ByVal SourceURL As String, ByRef Protocol As String, ByRef Host As String, ByRef Port As String, ByRef Path As String, ByRef Page As String, ByRef QueryString As String)
    Public MustOverride Sub separateURL(ByVal SourceURL As String, ByRef Protocol As String, ByRef Host As String, ByRef Path As String, ByRef Page As String, ByRef QueryString As String)
    Public MustOverride Function splitDelimited(ByVal WordList As String, ByVal Delimiter As String) As Object
End Class

