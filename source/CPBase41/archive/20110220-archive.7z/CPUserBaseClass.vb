

Public MustInherit Class CPUserBaseClass
    Public MustOverride Function getIdByLogin(ByVal Username As String, ByVal Password As String) As Integer
    '
    Public MustOverride Function isAdvancedEditing(ByVal ContentName As String) As Boolean
    Public MustOverride ReadOnly Property isAuthenticated() As Boolean
    Public MustOverride Function isAuthoring(ByVal ContentName As String) As Boolean
    Public MustOverride Function isEditing(ByVal ContentName As String) As Boolean
    Public MustOverride ReadOnly Property isEditingAnything() As Boolean
    Public MustOverride ReadOnly Property isGuest() As Boolean
    Public MustOverride Function isQuickEditing(ByVal ContentName As String) As Boolean
    Public MustOverride ReadOnly Property isRecognized() As Boolean
    Public MustOverride ReadOnly Property isWorkflowRendering() As Boolean
    Public MustOverride ReadOnly Property isNew() As Boolean
    '
    Public MustOverride ReadOnly Property isAdmin() As Boolean
    Public MustOverride Function isContentManager(Optional ByVal ContentName As String = "Page Content") As Boolean
    Public MustOverride ReadOnly Property isDeveloper() As Boolean
    Public MustOverride Function isInGroup(ByVal GroupName As String, Optional ByVal CheckUserID As Integer = 0) As Boolean
    Public MustOverride Function isInGroupList(ByVal GroupIDList As String, Optional ByVal CheckUserID As Integer = 0) As Boolean
    Public MustOverride ReadOnly Property isMember() As Boolean
    Public MustOverride Function recognize(ByVal UserID As Integer) As Boolean
    '
    Public MustOverride Function login(ByVal Username As String, ByVal Password As String, Optional ByVal SetAutoLogin As Boolean = False) As Boolean
    Public MustOverride Function loginByID(ByVal RecordID As String, Optional ByVal SetAutoLogin As Boolean = False) As Boolean
    Public MustOverride Function loginIsOK(ByVal Username As String, ByVal Password As String) As Boolean
    Public MustOverride Sub logout()
    Public MustOverride Function isNewLoginOK(ByVal Username As String, ByVal Password As String) As Boolean
    '
    Public MustOverride ReadOnly Property language() As String
    Public MustOverride ReadOnly Property languageID() As Integer
    Public MustOverride ReadOnly Property email() As String
    Public MustOverride ReadOnly Property id() As Integer
    Public MustOverride ReadOnly Property name() As String
    Public MustOverride ReadOnly Property organizationID() As Integer
    Public MustOverride ReadOnly Property password() As String
    Public MustOverride ReadOnly Property username() As String
End Class

