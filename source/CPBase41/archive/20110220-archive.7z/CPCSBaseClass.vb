
''' <summary>
''' CP.CS - The primary interface to the database. This object is similar to a recordset. It includes features of the content meta data. When a record is inserted, the default values of the record are available to read.
''' </summary>
''' <remarks></remarks>
Public MustInherit Class CPCSBaseClass
    'Friend Sub New(ByVal MainObj As Object, ByVal CsvObj As Object, ByRef CPParent As CPBaseClass)
    ''' <summary>
    ''' Inserts a new content row
    ''' </summary>
    ''' <param name="ContentName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function insert(ByVal ContentName As String) As Boolean
    ''' <summary>
    ''' Opens a record set
    ''' </summary>
    ''' <param name="ContentName"></param>
    ''' <param name="SQLCriteria"></param>
    ''' <param name="SortFieldList"></param>
    ''' <param name="ActiveOnly"></param>
    ''' <param name="SelectFieldList"></param>
    ''' <param name="PageSize"></param>
    ''' <param name="PageNumber"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function open(ByVal ContentName As String, Optional ByVal SQLCriteria As String = "", Optional ByVal SortFieldList As String = "", Optional ByVal ActiveOnly As Boolean = True, Optional ByVal SelectFieldList As String = "", Optional ByVal PageSize As Integer = 10, Optional ByVal PageNumber As Integer = 1) As Boolean
    ''' <summary>
    ''' Opens a record set with user records that are in a Group
    ''' </summary>
    ''' <param name="GroupList"></param>
    ''' <param name="SQLCriteria"></param>
    ''' <param name="SortFieldList"></param>
    ''' <param name="ActiveOnly"></param>
    ''' <param name="PageSize"></param>
    ''' <param name="PageNumber"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function openGroupUsers(ByVal GroupList As String, Optional ByVal SQLCriteria As String = "", Optional ByVal SortFieldList As String = "", Optional ByVal ActiveOnly As Boolean = True, Optional ByVal PageSize As Integer = 10, Optional ByVal PageNumber As Integer = 1) As Boolean
    ''' <summary>
    ''' deprecated. Use OpenGroupUsers.
    ''' </summary>
    ''' <param name="GroupList"></param>
    ''' <param name="SQLCriteria"></param>
    ''' <param name="SortFieldList"></param>
    ''' <param name="ActiveOnly"></param>
    ''' <param name="PageSize"></param>
    ''' <param name="PageNumber"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function openGroupListUsers(ByVal GroupList As String, Optional ByVal SQLCriteria As String = "", Optional ByVal SortFieldList As String = "", Optional ByVal ActiveOnly As Boolean = True, Optional ByVal PageSize As Integer = 10, Optional ByVal PageNumber As Integer = 1) As Boolean
    ''' <summary>
    ''' Opens a record set based on an sql statement
    ''' </summary>
    ''' <param name="SQL"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function OpenSQL(ByVal SQL As String) As Boolean 'Implements BaseClasses.CPCSBaseClass.OpenSQL
    ''' <summary>
    ''' Opens a record set based on an sql statement
    ''' </summary>
    ''' <param name="DataSourcename"></param>
    ''' <param name="SQL"></param>
    ''' <param name="PageSize"></param>
    ''' <param name="PageNumber"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function OpenSQL(ByVal SQL As String, ByVal DataSourcename As String, Optional ByVal PageSize As Integer = 10, Optional ByVal PageNumber As Integer = 1) As Boolean 'Implements BaseClasses.CPCSBaseClass.OpenSQL
    ''' <summary>
    '''  Closes an open record set
    ''' </summary>
    ''' <remarks></remarks>
    Public MustOverride Sub close()
    ''' <summary>
    ''' Returns a form input element based on a content field definition
    ''' </summary>
    ''' <param name="ContentName"></param>
    ''' <param name="FieldName"></param>
    ''' <param name="Height"></param>
    ''' <param name="Width"></param>
    ''' <param name="HtmlId"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function GetFormInput(ByVal ContentName As String, ByVal FieldName As String, Optional ByVal Height As String = "", Optional ByVal Width As String = "", Optional ByVal HtmlId As String = "") As Object 'Implements BaseClasses.CPCSBaseClass.GetFormInput
    ''' <summary>
    ''' Deletes the current row
    ''' </summary>
    ''' <remarks></remarks>
    Public MustOverride Sub delete()
    ''' <summary>
    ''' Returns true if the given field is valid for this record set
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function fieldOK(ByVal FieldName As String) As Boolean
    ''' <summary>
    ''' Move to the first record in the current record set
    ''' </summary>
    ''' <remarks></remarks>
    Public MustOverride Sub goFirst()
    ''' <summary>
    ''' Returns an icon linked to the add function in the admin site for this content
    ''' </summary>
    ''' <param name="PresetNameValueList"></param>
    ''' <param name="AllowPaste"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getAddLink(Optional ByVal PresetNameValueList As String = "", Optional ByVal AllowPaste As Boolean = False) As String
    ''' <summary>
    ''' Returns the field value cast as a boolean
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getBoolean(ByVal FieldName As String) As Boolean
    ''' <summary>
    ''' Returns the field value cast as a date
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getDate(ByVal FieldName As String) As Date
    ''' <summary>
    ''' Returns an icon linked to the edit function in the admin site for this content
    ''' </summary>
    ''' <param name="AllowCut"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getEditLink(Optional ByVal AllowCut As Boolean = False) As String
    ''' <summary>
    ''' Returns the filename for the field, if a filename is related to the field type. Use this call to create the appropriate filename when a new file is added. The filename with the appropriate path is created or returned. This file and path is relative to the site's content file path and does not include a leading slash. To use this file in a URL, prefix with cp.site.filepath.
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <param name="OriginalFilename"></param>
    ''' <param name="ContentName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getFilename(ByVal FieldName As String, Optional ByVal OriginalFilename As String = "", Optional ByVal ContentName As String = "") As String
    ''' <summary>
    ''' Returns the field value cast as an integer
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getInteger(ByVal FieldName As String) As Integer
    ''' <summary>
    ''' Returns the field value cast as a number (double)
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getNumber(ByVal FieldName As String) As Double
    ''' <summary>
    ''' Returns the number of rows in the result.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getRowCount() As Integer
    ''' <summary>
    ''' returns the query used to generate the results
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getSQL() As String
    ''' <summary>
    ''' Returns the text equivalent of the result. For most field types, this is just the result cast as text. For field types that store text in files, the text is returned instead of the filename. These include textfile, cssfile, javascriptfile. For file types that do not contain text, the filename is returned. These include filetype and imagefiletype. For lookup field types, getText returns the name of the lookup, not the Id or index. To get the Id or Index, use getInteger.
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getText(ByVal FieldName As String) As String
    ''' <summary>
    ''' Deprecated. Returns the filename for field types that store text in files.
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function getTextFile(ByVal FieldName As String) As String
    ''' <summary>
    ''' Move to the next record in a result set.
    ''' </summary>
    ''' <remarks></remarks>
    Public MustOverride Sub goNext()
    ''' <summary>
    ''' Returns true if there is valid data in the current row of the result set.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public MustOverride Function ok() As Boolean
    ''' <summary>
    ''' Forces a save of any changes made to the current row. A save occurs automatically when the content set is closed or when it moves to another row.
    ''' </summary>
    ''' <remarks></remarks>
    Public MustOverride Sub save()
    ''' <summary>
    ''' Sets a value in a field of the current row.
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <param name="FieldValue"></param>
    ''' <remarks></remarks>
    Public MustOverride Sub setField(ByVal FieldName As String, ByVal FieldValue As String)
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <param name="Copy"></param>
    ''' <param name="ContentName"></param>
    ''' <remarks></remarks>
    Public MustOverride Sub setFile(ByVal FieldName As String, ByVal Copy As String, ByVal ContentName As String)
    ''' <summary>
    ''' Processes a value from the incoming request to a field in the current row.
    ''' </summary>
    ''' <param name="FieldName"></param>
    ''' <param name="RequestName"></param>
    ''' <remarks></remarks>
    Public MustOverride Sub setFormInput(ByVal FieldName As String, Optional ByVal requestName As String = "")
End Class
