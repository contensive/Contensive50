
cpBase.dll

- for past addons to work
1) it must have assembly version set to 4.1.2.0 (the first version used for addons)
2) it must be singed with CPBase2.snk signing file

It is ok to 
1) add new methods
2) add new signatures to methods

To support active scripting
1) only one signature can be supported for each method

